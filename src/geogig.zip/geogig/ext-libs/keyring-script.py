#!c:\python27\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'keyring==4.0','console_scripts','keyring'
__requires__ = 'keyring==4.0'
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.exit(
        load_entry_point('keyring==4.0', 'console_scripts', 'keyring')()
    )
